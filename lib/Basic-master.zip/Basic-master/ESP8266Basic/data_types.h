#define _INT32_ long
#define _UINT32_ unsigned long
#define _INT16_ int
#define _UINT16_ unsigned int
