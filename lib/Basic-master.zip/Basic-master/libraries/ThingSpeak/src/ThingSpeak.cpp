/*
  ThingSpeak Communication Library For Arduino
  
  ThingSpeak ( https://www.thingspeak.com ) is a free IoT service for building
  systems that collect, analyze, and react to their environments.
  
  Copyright 2015, The MathWorks, Inc.
 
  See the accompaning licence file for licensing information.
*/

#include "ThingSpeak.h"
ThingSpeakClass ThingSpeak;
