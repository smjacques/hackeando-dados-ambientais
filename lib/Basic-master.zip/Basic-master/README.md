Basic
Basic Interpreter from scratch especialy for the ESP8266.

http://esp8266basic.com

http://www.esp8266basic.com/language-reference.html

http://www.esp8266basic.com/flashing-instructions.html



The libraries folder contains the libraries currently being used.
Look at licence information for each.

Compile using the arduino ESP8266 package using the staging version 2.0.0-rc1

Special thanks to the people who have worked to extend and improve ESP BASIC.
Contributers include MMiscool, Cicciob and Rotohammer.

